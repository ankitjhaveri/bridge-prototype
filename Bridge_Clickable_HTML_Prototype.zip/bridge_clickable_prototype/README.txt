
# Bridge – Clickable MVP Prototype (HTML)

Open `index.html` in your browser to demo Bridge:
- Home Dashboard → DealFlow → MoneyMap → TeamBoard
- New Deal Wizard (3 steps + confirm)
- Guided onboarding tour (Start Tour button in the header)

## Figma Import (Optional)
1) In Figma, create a new file.
2) Drag `index.html` in as a reference or recreate with existing assets.
3) Use the included wizard spec + demo script from previous downloads to link frames.
